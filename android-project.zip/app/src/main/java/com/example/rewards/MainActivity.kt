// Android client (Kotlin + Jetpack Compose).
package com.example.rewards

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.*
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

const val BASE = "https://rewards-backend-yx5r.onrender.com"   // your Render backend
const val AD_UNIT = "ca-app-pub-3940256099942544/5224354917"   // Google TEST rewarded unit; replace after approval

object Api {
    private val http = OkHttpClient()
    var token: String? = null
    suspend fun call(method: String, path: String, body: JSONObject? = null): JSONObject = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(BASE + path)
            token?.let { b.header("Authorization", "Bearer $it") }
            val rb = (body?.toString() ?: "{}").toRequestBody("application/json".toMediaType())
            when (method) { "POST" -> b.post(rb); "DELETE" -> b.delete(); else -> b.get() }
            http.newCall(b.build()).execute().use { JSONObject(it.body?.string() ?: "{}") }
        } catch (e: Exception) {
            JSONObject().put("error", "Network error. Server may be waking up, try again in a minute.")
        }
    }
}

class MainActivity : ComponentActivity() {
    private var ad: RewardedAd? = null
    private var userId: String = ""

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        MobileAds.initialize(this)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        Api.token = prefs.getString("token", null)
        setContent { MaterialTheme { Surface { App(prefs) } } }
    }

    private fun loadAd() {
        RewardedAd.load(this, AD_UNIT, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(a: RewardedAd) {
                // Server-side verification: the backend reads this user_id from the SSV callback.
                a.setServerSideVerificationOptions(ServerSideVerificationOptions.Builder().setUserId(userId).build())
                ad = a
            }
            override fun onAdFailedToLoad(e: LoadAdError) { ad = null }
        })
    }

    @Composable
    fun App(prefs: android.content.SharedPreferences) {
        val scope = rememberCoroutineScope()
        var loggedIn by remember { mutableStateOf(Api.token != null) }
        var phone by remember { mutableStateOf("") }
        var otp by remember { mutableStateOf("") }
        var refInput by remember { mutableStateOf("") }
        var otpSent by remember { mutableStateOf(false) }
        var info by remember { mutableStateOf<JSONObject?>(null) }
        var upi by remember { mutableStateOf("") }
        var msg by remember { mutableStateOf("") }

        suspend fun refresh() {
            val me = Api.call("GET", "/me")
            if (me.has("error")) { msg = me.optString("error"); loggedIn = false; Api.token = null; return }
            info = me
            userId = me.optString("user_id")
            loadAd()
        }
        LaunchedEffect(loggedIn) { if (loggedIn) refresh() }

        Column(Modifier.padding(20.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!loggedIn) {
                Text("Sign in", style = MaterialTheme.typography.headlineMedium)
                OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") })
                if (!otpSent) OutlinedTextField(refInput, { refInput = it }, label = { Text("Referral code (optional)") })
                if (otpSent) OutlinedTextField(otp, { otp = it }, label = { Text("OTP") })
                Button(onClick = {
                    scope.launch {
                        if (!otpSent) {
                            val r = Api.call("POST", "/auth/request-otp", JSONObject().put("phone", phone))
                            if (r.has("error")) msg = r.optString("error") else { otpSent = true; msg = "" }
                        } else {
                            val devId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                            val r = Api.call("POST", "/auth/verify", JSONObject().put("phone", phone).put("code", otp)
                                .put("device_id", devId).put("ref_code", refInput.trim()))
                            if (r.has("token")) {
                                Api.token = r.getString("token"); prefs.edit().putString("token", Api.token).apply(); loggedIn = true; msg = ""
                            } else msg = r.optString("error")
                        }
                    }
                }) { Text(if (otpSent) "Verify" else "Send OTP") }
            } else info?.let { i ->
                Text("Balance: ₹%.2f".format(i.getInt("balance_paise") / 100.0), style = MaterialTheme.typography.headlineMedium)
                Text("Ads left today: ${i.getInt("ads_left")}")
                Button(onClick = {
                    ad?.show(this@MainActivity) { scope.launch { delay(4000); refresh() } } ?: run { msg = "Ad not ready, try again" }
                }) { Text("Watch ad") }
                Divider()
                OutlinedTextField(upi, { upi = it }, label = { Text("UPI ID") })
                Button(onClick = {
                    scope.launch {
                        val r = Api.call("POST", "/withdraw", JSONObject().put("upi", upi))
                        msg = if (r.has("ok")) "Withdrawal requested" else r.optString("error"); refresh()
                    }
                }) { Text("Withdraw (min ₹100)") }
                OutlinedButton(onClick = {
                    val text = "Earn by watching ads! Install the app and enter my referral code ${i.getString("ref_code")} when you sign in."
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, text), "Share"))
                }) { Text("Invite friends (₹10 each)") }
                TextButton(onClick = { scope.launch { Api.call("DELETE", "/me"); prefs.edit().clear().apply(); loggedIn = false } }) {
                    Text("Delete my account")
                }
            }
            if (msg.isNotEmpty()) Text(msg)
        }
    }
}
