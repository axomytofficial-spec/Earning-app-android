// Rewardly: WebView app. The design lives in assets/index.html; this file connects it to the server and AdMob.
package com.example.rewards

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.*
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

const val BASE = "https://rewards-backend-yx5r.onrender.com"   // your Render backend
const val AD_UNIT = "ca-app-pub-3940256099942544/5224354917"   // Google TEST rewarded unit; replace after approval

object Api {
    private val http = OkHttpClient.Builder()
        .connectTimeout(70, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(70, java.util.concurrent.TimeUnit.SECONDS).build()
    var token: String? = null
    suspend fun call(method: String, path: String, body: String): JSONObject = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(BASE + path)
            token?.let { b.header("Authorization", "Bearer $it") }
            val rb = (if (body.isEmpty()) "{}" else body).toRequestBody("application/json".toMediaType())
            when (method) { "POST" -> b.post(rb); "DELETE" -> b.delete(); else -> b.get() }
            http.newCall(b.build()).execute().use { JSONObject(it.body?.string() ?: "{}") }
        } catch (e: Exception) {
            JSONObject().put("error", "Network error. Server may be waking up, try again in a minute.")
        }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var ad: RewardedAd? = null
    private var adUser = ""
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun loadAd() {
        RewardedAd.load(this, AD_UNIT, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(a: RewardedAd) { ad = a }
            override fun onAdFailedToLoad(e: LoadAdError) { ad = null }
        })
    }

    inner class Bridge(private val prefs: android.content.SharedPreferences) {
        @JavascriptInterface fun api(id: String, method: String, path: String, body: String) {
            scope.launch {
                val r = Api.call(method, path, body)
                js("window.__cb('$id', ${JSONObject.quote(r.toString())})")
            }
        }
        @JavascriptInterface fun getToken(): String = prefs.getString("token", "") ?: ""
        @JavascriptInterface fun setToken(t: String) {
            Api.token = t.ifEmpty { null }
            prefs.edit().putString("token", t).apply()
        }
        @JavascriptInterface fun deviceId(): String =
            Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        @JavascriptInterface fun prepare(uid: String) { adUser = uid; runOnUiThread { if (ad == null) loadAd() } }
        @JavascriptInterface fun showAd(uid: String) {
            runOnUiThread {
                val a = ad
                if (a == null) { js("window.__adFail('Ad not ready, try again in a moment')"); loadAd(); return@runOnUiThread }
                a.setServerSideVerificationOptions(ServerSideVerificationOptions.Builder().setUserId(uid).build())
                a.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() { ad = null; loadAd() }
                    override fun onAdFailedToShowFullScreenContent(e: AdError) { ad = null; loadAd(); js("window.__adFail('Could not show the ad')") }
                }
                a.show(this@MainActivity) { js("window.__adDone()") }
            }
        }
        @JavascriptInterface fun share(text: String) {
            runOnUiThread {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, text), "Share"))
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.parseColor("#07030F")
        window.navigationBarColor = Color.parseColor("#07030F")
        MobileAds.initialize(this)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        Api.token = prefs.getString("token", null)?.ifEmpty { null }
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#07030F"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(prefs), "Bridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this) {
            web.evaluateJavascript(
                "(function(){var b=document.querySelector('.screen:not([hidden]) [data-back]');if(b){b.click();return 1}return 0})()"
            ) { r -> if (r != "1") finish() }
        }
    }
}
